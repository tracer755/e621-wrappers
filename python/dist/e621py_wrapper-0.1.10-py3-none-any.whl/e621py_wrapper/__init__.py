from . import e621_wrapper

client = e621_wrapper.client